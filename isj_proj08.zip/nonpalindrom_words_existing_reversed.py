#!/usr/bin/env python3

import fileinput
words = set()
a = set()
for line in fileinput.FileInput():
	w = line.rstrip()
	rev = w[::-1]
	if w != rev:
		words.add(w)
		a.add(rev)
result = list(words&a)
print(sorted(result))

